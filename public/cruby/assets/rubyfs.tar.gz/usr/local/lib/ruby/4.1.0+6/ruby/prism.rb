# frozen_string_literal: true
# :markup: markdown
#--
# rbs_inline: enabled

# The Ruby::Prism Ruby parser.
#
# "Parsing Ruby is suddenly manageable!"
#   - You, hopefully
#
module Ruby::Prism
  # There are many files in prism that are templated to handle every node type,
  # which means the files can end up being quite large. We autoload them to make
  # our require speed faster since consuming libraries are unlikely to use all
  # of these features.

  autoload :BasicVisitor, "ruby/prism/visitor"
  autoload :Compiler, "ruby/prism/compiler"
  autoload :DesugarCompiler, "ruby/prism/desugar_compiler"
  autoload :Dispatcher, "ruby/prism/dispatcher"
  autoload :DotVisitor, "ruby/prism/dot_visitor"
  autoload :DSL, "ruby/prism/dsl"
  autoload :InspectVisitor, "ruby/prism/inspect_visitor"
  autoload :LexCompat, "ruby/prism/lex_compat"
  autoload :MutationCompiler, "ruby/prism/mutation_compiler"
  autoload :NodeFind, "ruby/prism/node_find"
  autoload :Pattern, "ruby/prism/pattern"
  autoload :Reflection, "ruby/prism/reflection"
  autoload :Relocation, "ruby/prism/relocation"
  autoload :Serialize, "ruby/prism/serialize"
  autoload :StringQuery, "ruby/prism/string_query"
  autoload :Translation, "ruby/prism/translation"
  autoload :Visitor, "ruby/prism/visitor"

  # Some of these constants are not meant to be exposed, so marking them as
  # private here.

  if RUBY_ENGINE != "jruby"
    private_constant :LexCompat
    private_constant :NodeFind
  end

  # Raised when requested to parse as the currently running Ruby version but Ruby::Prism has no support for it.
  class CurrentVersionError < ArgumentError
    # Initialize a new exception for the given ruby version string.
    #
    #: (String version) -> void
    def initialize(version)
      message = +"invalid version: Requested to parse as `version: 'current'`; "
      major, minor, =
        if version.match?(/\A\d+\.\d+.\d+\z/)
          version.split(".").map(&:to_i)
        end

      if major && minor && ((major < 3) || (major == 3 && minor < 3))
        message << " #{version} is below the minimum supported syntax."
      else
        message << " #{version} is unknown. Please update the `prism` gem."
      end

      super(message)
    end
  end

  # :call-seq:
  #   lex_compat(source, **options) -> LexCompat::Result
  #
  # Returns a parse result whose value is an array of tokens that closely
  # resembles the return value of Ripper.lex.
  #
  # For supported options, see Ruby::Prism.parse.
  #
  #: (String source, **untyped options) -> LexCompat::Result
  def self.lex_compat(source, **options)
    LexCompat.new(source, **options).result # steep:ignore
  end

  # :call-seq:
  #   load(source, serialized, freeze) -> ParseResult
  #
  # Load the serialized AST using the source as a reference into a tree.
  #
  #: (String source, String serialized, ?bool freeze) -> ParseResult
  def self.load(source, serialized, freeze = false)
    Serialize.load_parse(source, serialized, freeze)
  end

  # Given a Method, UnboundMethod, Proc, or Thread::Backtrace::Location,
  # returns the Ruby::Prism node representing it. On CRuby, this uses node_id for
  # an exact match. On other implementations, it falls back to best-effort
  # matching by source location line number.
  #
  #: (Method | UnboundMethod | Proc | Thread::Backtrace::Location callable) -> Node?
  def self.find(callable)
    NodeFind.find(callable)
  end

  # @rbs!
  #    VERSION: String
  #    BACKEND: :CEXT | :FFI
  #
  #    interface _Stream
  #      def gets: (?Integer integer) -> (String | nil)
  #    end
  #
  #    def self.parse:               (String source,  ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> ParseResult
  #    def self.profile:             (String source,  ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> void
  #    def self.lex:                 (String source,  ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> LexResult
  #    def self.parse_lex:           (String source,  ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> ParseLexResult
  #    def self.dump:                (String source,  ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> String
  #    def self.parse_comments:      (String source,  ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> Array[Comment]
  #    def self.parse_success?:      (String source,  ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> bool
  #    def self.parse_failure?:      (String source,  ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> bool
  #    def self.parse_stream:        (_Stream stream, ?filepath: String, ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> ParseResult
  #    def self.parse_file:          (path filepath,                     ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> ParseResult
  #    def self.profile_file:        (path filepath,                     ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> void
  #    def self.lex_file:            (path filepath,                     ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> LexResult
  #    def self.parse_lex_file:      (path filepath,                     ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> ParseLexResult
  #    def self.dump_file:           (path filepath,                     ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> String
  #    def self.parse_file_comments: (path filepath,                     ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> Array[Comment]
  #    def self.parse_file_success?: (path filepath,                     ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> bool
  #    def self.parse_file_failure?: (path filepath,                     ?attach_comments: bool, ?command_line: String, ?encoding: Encoding | false, ?freeze: bool, ?frozen_string_literal: bool, ?line: Integer, ?main_script: bool, ?partial_script: bool, ?raise_error: Symbol | true, ?scopes: Array[Array[Symbol]], ?version: String) -> bool
end

require_relative "prism/polyfill/byteindex"
require_relative "prism/polyfill/warn"
require_relative "prism/node"
require_relative "prism/node_ext"
require_relative "prism/parse_result"

# This is a Ruby implementation of the prism parser. If we're running on CRuby
# and we haven't explicitly set the PRISM_FFI_BACKEND environment variable, then
# it's going to require the built library. Otherwise, it's going to require a
# module that uses FFI to call into the library.
if RUBY_ENGINE == "ruby" and !ENV["PRISM_FFI_BACKEND"]
  # The C extension is the default backend on CRuby.
  Ruby::Prism::BACKEND = :CEXT

  begin
    # The precompiled native libraries are in <gem_dir>/lib/prism/<ruby_version>
    require_relative "prism/#{RUBY_VERSION[/\d+\.\d+/]}/prism"
  rescue LoadError => e
    if e.message.include?("GLIBC")
      warn(<<~EOM)

        ERROR: It looks like you're trying to use Ruby::Prism as a precompiled native gem on a system
               with an unsupported version of glibc.

          #{e.message}

          If that's the case, then please install Ruby::Prism via the `ruby` platform gem:
              gem install prism --platform=ruby
          or, in your Gemfile:
              gem "prism", force_ruby_platform: true

      EOM
      raise e
    end

    # Precompiled library isn't available, fall back to the library compiled at installation time.
    require "ruby/prism/prism"
  end
else
  # The FFI backend is used on other Ruby implementations.
  Ruby::Prism::BACKEND = :FFI

  require_relative "prism/ffi"
end
