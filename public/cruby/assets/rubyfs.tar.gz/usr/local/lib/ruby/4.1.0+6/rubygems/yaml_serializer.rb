# frozen_string_literal: true

# Skip reloading when an identical copy (e.g. the one shipped inside the Bundler
# gem) was already required from a different path, to avoid redefinition warnings.
return if defined?(Gem::YAMLSerializer)

unless defined?(Psych::VERSION)
  module Psych
    class Exception < ::RuntimeError; end
    class SyntaxError < Exception; end
    class DisallowedClass < Exception; end
    class BadAlias < Exception; end
    class AliasesNotEnabled < BadAlias; end
  end
end

module Gem
  module YAMLSerializer
    Scalar = Struct.new(:value, :tag, :anchor)
    Mapping = Struct.new(:pairs, :tag, :anchor)
    Sequence = Struct.new(:items, :tag, :anchor)
    AliasRef = Struct.new(:name)

    class Parser
      # A plain (unquoted) mapping key followed by ":". "#" inside a key is
      # literal unless preceded by a space (which would start a comment).
      # Like Psych, spaces and tabs may separate the ":" from the value.
      MAPPING_KEY_RE = /\G((?:[^#:\s]|:[^ \t])(?:[^#:]|:[^ \t]|(?<=[^ ])#)*):(?:[ \t]+(.*))?$/
      # A quoted mapping key followed by ":". A whole-line quoted scalar
      # cannot match because its closing quote is at the end of the line.
      QUOTED_KEY_RE = /\G("(?:[^"\\]|\\.)*"|'(?:[^']|'')*'):(?:[ \t]+(.*))?$/
      # An entry of a flow sequence. A quoted entry may contain commas.
      FLOW_SEQUENCE_ENTRY_RE = /"(?:[^"\\]|\\.)*"|'(?:[^']|'')*'|[^,\s](?:[^,]*[^,\s])?/
      SEQUENCE_ENTRY_RE = /\G-(?: |\z)/
      # A quoted scalar whose closing quote is on a later line.
      OPEN_QUOTED_RE = /\A(?:! )?(?:"(?>(?:[^"\\]|\\.)*)(\\)?|'(?>(?:[^']|'')*))\z/
      RUBY_OBJECT_TAG_RE = %r{\G!ruby/object:}
      LSTRIP_BYTES = [0, 9, 10, 11, 12, 13, 32].freeze
      UTF8_BOM_BYTES = [0xEF, 0xBB, 0xBF].freeze
      MAX_NESTING_DEPTH = 1_000
      NULL_SCALARS = %w[~ null].freeze
      BLANK_RE = /\A[\0\s]*\z/
      BLANK_OR_COMMENT_RE = /\A[\0\s]*(?:#|\z)/
      DOCUMENT_END_RE = /\A\.\.\.(?:[ \t]|\z)/

      STRING_UNESCAPES = {
        "\\\\" => "\\",
        "\\\"" => "\"",
        "\\ " => " ",
        "\\0" => "\0",
        "\\a" => "\a",
        "\\b" => "\b",
        "\\t" => "\t",
        "\\n" => "\n",
        "\\v" => "\v",
        "\\f" => "\f",
        "\\r" => "\r",
        "\\e" => "\e",
        "\\N" => "\u0085",
        "\\_" => "\u00A0",
        "\\L" => "\u2028",
        "\\P" => "\u2029",
      }.freeze

      def initialize(source)
        raise TypeError, "no implicit conversion of nil into String" if source.nil?

        source = strip_bom(source)
        # Keep trailing empty lines, which a block scalar with keep chomping
        # ("|+") preserves, but not the empty string after the final line
        # break.
        @lines = source.split(/\r?\n/, -1)
        @lines.pop if @lines.last == ""
        @lines.each(&:freeze)
        @anchors = {}
        @depth = 0
        strip_document_end
        strip_document_prefix
      end

      def parse
        return nil if @lines.empty?

        root = nil
        while @lines.any?
          before = @lines.size
          node = parse_node(-1)
          @lines.shift if @lines.size == before && @lines.any?

          if root.is_a?(Mapping) && node.is_a?(Mapping)
            root.pairs.concat(node.pairs)
          elsif root.nil?
            root = node
          end
        end
        root
      end

      private

      # Byte-wise, as checksums.yaml is read as binary unlike config files,
      # and binary cannot be compared with a UTF-8 string holding the BOM.
      def strip_bom(source)
        return source unless UTF8_BOM_BYTES.each_with_index.all? {|byte, i| source.getbyte(i) == byte }

        source.byteslice(UTF8_BOM_BYTES.size..)
      end

      def strip_document_end
        index = @lines.index {|line| DOCUMENT_END_RE.match?(line) }
        @lines.slice!(index..) if index
      end

      def strip_document_prefix
        return if @lines.empty?
        return unless @lines[0]&.start_with?("---")

        if @lines[0].strip == "---"
          @lines.shift
        else
          @lines[0] = @lines[0].sub(/^---\s*/, "")
        end
      end

      def parse_node(base_indent)
        @depth += 1
        raise_max_nesting! if @depth > MAX_NESTING_DEPTH

        skip_blank_and_comments
        return nil if @lines.empty?

        line = @lines[0]
        indent = indent_of(line)
        return nil if indent < base_indent

        return parse_alias_ref if /\G\*/.match?(line, indent)

        pos = indent
        if /\G&/.match?(line, indent) && (anchor = consume_anchor)
          # A lone anchor line, e.g. "--- &1", anchors the node on the next line.
          skip_blank_and_comments
          return register_anchor(anchor, nil) if @lines.empty? || current_indent < base_indent
          line = @lines[0]
          indent = pos = indent_of(line)
        end

        if SEQUENCE_ENTRY_RE.match?(line, pos)
          parse_sequence(indent, anchor)
        elsif QUOTED_KEY_RE.match?(line, pos)
          # A mapping whose key is quoted, e.g. '"have: colon": value'.
          parse_mapping(indent, anchor)
        elsif (/\G"/.match?(line, pos) && line.end_with?("\"")) ||
              (/\G'/.match?(line, pos) && line.end_with?("'"))
          # A whole-line quoted scalar, e.g. '"system: foo: bar"'. It may
          # contain ": ", so it must be checked before MAPPING_KEY_RE.
          parse_plain_scalar(indent, anchor)
        elsif MAPPING_KEY_RE.match?(line, pos) && !RUBY_OBJECT_TAG_RE.match?(line, pos)
          parse_mapping(indent, anchor)
        elsif RUBY_OBJECT_TAG_RE.match?(line, pos)
          parse_tagged_node(indent, anchor)
        elsif /\G\|/.match?(line, pos)
          modifier = line[pos + 1, line.size].strip
          @lines.shift
          register_anchor(anchor, Scalar.new(parse_block_scalar(indent, modifier)))
        else
          parse_plain_scalar(indent, anchor)
        end
      ensure
        @depth -= 1
      end

      def parse_sequence(indent, anchor)
        items = []
        while @lines.any?
          skip_blank_and_comments
          break if @lines.empty?
          line = @lines[0]
          break unless indent_of(line) == indent && SEQUENCE_ENTRY_RE.match?(line, indent)
          @lines.shift
          content = line[indent + 1, line.size]
          content.strip!
          item_anchor = nil
          item_anchor, content = extract_anchor(content) if content.start_with?("&")
          item = parse_sequence_item(content, indent)
          items << register_anchor(item_anchor, item)
        end
        register_anchor(anchor, Sequence.new(items))
      end

      def parse_sequence_item(content, indent)
        if content.start_with?("*")
          parse_inline_alias(content)
        elsif content.empty?
          skip_blank_and_comments
          @lines.any? && current_indent > indent ? parse_node(indent + 1) : nil
        elsif content.start_with?("!ruby/object:")
          parse_tagged_content(content.strip, indent)
        elsif content.start_with?("!binary ")
          parse_binary_value(content, indent)
        elsif content.start_with?("-")
          @lines.unshift("#{" " * (indent + 2)}#{content}")
          parse_node(indent)
        elsif QUOTED_KEY_RE.match?(content) ||
              (MAPPING_KEY_RE.match?(content) && !content.start_with?("!ruby/object:") &&
               !OPEN_QUOTED_RE.match?(content))
          @lines.unshift("#{" " * (indent + 2)}#{content}")
          parse_node(indent)
        elsif content.start_with?("|")
          Scalar.new(parse_block_scalar(indent, content[1..].to_s.strip))
        else
          parse_inline_scalar(content, indent)
        end
      end

      def parse_mapping(indent, anchor)
        pairs = []
        while @lines.any?
          skip_blank_and_comments
          break if @lines.empty?
          line = @lines[0]
          break unless indent_of(line) == indent

          if (match = QUOTED_KEY_RE.match(line, indent))
            key = coerce(match[1])
          elsif (match = MAPPING_KEY_RE.match(line, indent)) && !RUBY_OBJECT_TAG_RE.match?(line, indent)
            key = match[1]
            key.strip!
            key = decode_binary_tag(key) if key.start_with?("!binary ")
          else
            break
          end
          @lines.shift
          val = match[2]
          val&.strip!
          val = strip_comment(val || "")

          val_anchor = nil
          val_anchor, val = extract_anchor(val) if val.start_with?("&")
          value = parse_mapping_value(val, indent)
          value = register_anchor(val_anchor, value) if val_anchor

          pairs << key << value
        end
        register_anchor(anchor, Mapping.new(pairs))
      end

      def parse_mapping_value(val, indent)
        if val.start_with?("*")
          parse_inline_alias(val)
        elsif val.start_with?("!ruby/object:")
          parse_tagged_content(val.strip, indent)
        elsif val.start_with?("!binary ")
          parse_binary_value(val, indent)
        elsif val.empty?
          skip_blank_and_comments
          line = @lines[0]
          if line && indent_of(line) == indent && SEQUENCE_ENTRY_RE.match?(line, indent)
            parse_node(indent)
          else
            parse_node(indent + 1)
          end
        elsif val == "[]"
          Sequence.new([])
        elsif val == "{}"
          Mapping.new([])
        elsif val.start_with?("|")
          Scalar.new(parse_block_scalar(indent, val[1..].to_s.strip))
        else
          parse_inline_scalar(val, indent)
        end
      end

      def parse_tagged_node(indent, anchor)
        tag = @lines.shift.strip
        nested = parse_node(indent)
        apply_tag(nested, tag, anchor)
      end

      def parse_tagged_content(tag, indent)
        nested = parse_node(indent)
        apply_tag(nested, tag, nil)
      end

      def apply_tag(node, tag, anchor)
        if node.is_a?(Mapping)
          node.tag = tag
          node.anchor = anchor
          node
        else
          Mapping.new(["value", node], tag, anchor)
        end
      end

      def parse_block_scalar(base_indent, modifier)
        parts = []
        indentation = modifier[/\A[+-]?([1-9])/, 1]
        chomping = modifier[/\A[1-9]?([+-])/, 1]
        block_indent = indentation && base_indent + indentation.to_i

        while @lines.any?
          line = @lines[0]
          if BLANK_RE.match?(line)
            parts << line[block_indent..] if block_indent && line.size > block_indent
            parts << "\n"
            @lines.shift
          else
            line_indent = indent_of(line)
            break if line_indent <= base_indent
            block_indent ||= line_indent
            parts << @lines.shift[block_indent..].to_s << "\n"
          end
        end

        res = parts.join
        unless chomping == "+"
          res.delete_suffix!("\n") while res.end_with?("\n")
          # Clipping keeps the final line break but drops trailing empty lines.
          res << "\n" if chomping.nil? && !res.empty?
        end
        res
      end

      def parse_plain_scalar(indent, anchor)
        val = @lines.shift.strip
        result = coerce(val)
        return register_anchor(anchor, result) if result.is_a?(Mapping) || result.is_a?(Sequence)

        fold_continuation_lines(result, val, indent)
        register_anchor(anchor, Scalar.new(result))
      end

      def parse_inline_scalar(val, indent)
        result = coerce(val)
        return result if result.is_a?(Mapping) || result.is_a?(Sequence)

        fold_continuation_lines(result, val, indent)
        Scalar.new(result)
      end

      def fold_continuation_lines(result, val, indent)
        return unless result.is_a?(String)

        return result.replace(fold_quoted_lines(val.delete_prefix("! "), indent)) if OPEN_QUOTED_RE.match?(val)

        while @lines.any? && !BLANK_OR_COMMENT_RE.match?(@lines[0]) && current_indent > indent
          result << " " << @lines.shift.strip
        end
      end

      def fold_quoted_lines(val, indent)
        open = OPEN_QUOTED_RE.match(val)
        breaks = +""
        while open && @lines.any? && (BLANK_RE.match?(@lines[0]) || current_indent > indent)
          line = @lines.shift.strip
          next breaks << "\n" if line.empty?

          val.chop! if open[1]
          val << (breaks.empty? && !open[1] ? " " : breaks) << line
          breaks.clear
          open = OPEN_QUOTED_RE.match("#{val[0]}#{line}")
        end
        coerce(val)
      end

      def coerce(val, depth = 0)
        raise_max_nesting! if depth > MAX_NESTING_DEPTH

        val = val.sub(/^! /, "") if val.start_with?("! ")

        if val.size >= 2 && val.start_with?("\"") && val.end_with?("\"")
          inner = val[1..-2]
          return inner unless inner.include?("\\")
          inner.gsub(/\\(?:["\\ 0abtnvfreN_LP]|x\h{2}|u\h{4}|U\h{8})/) do |m|
            char = STRING_UNESCAPES[m] || unescape_code_point(m)
            # Metadata is read as binary, where non-ASCII text stays as UTF-8 bytes.
            Encoding.compatible?(inner, char) ? char : char.b
          end
        elsif val.size >= 2 && val.start_with?("'") && val.end_with?("'")
          inner = val[1..-2]
          inner.include?("''") ? inner.gsub("''", "'") : inner
        elsif val == "true"
          true
        elsif val == "false"
          false
        elsif NULL_SCALARS.include?(val)
          nil
        elsif val == "{}"
          Mapping.new([])
        elsif val =~ /^\[(.*)\]$/
          inner = $1.strip
          return Sequence.new([]) if inner.empty?
          items = inner.scan(FLOW_SEQUENCE_ENTRY_RE).map {|e| Scalar.new(coerce(e, depth + 1)) }
          Sequence.new(items)
        elsif /\A\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}:\d{2})?/.match?(val)
          begin
            Time.new(val)
          rescue ArgumentError
            # date-only format like "2024-06-15" is not supported by Time.new
            if /\A(\d{4})-(\d{2})-(\d{2})\z/.match(val)
              Time.utc($1.to_i, $2.to_i, $3.to_i)
            else
              val
            end
          end
        elsif /^-?\d+$/.match?(val)
          val.to_i
        else
          val
        end
      end

      def unescape_code_point(escape)
        code = escape[2..].hex
        return escape if code > 0x10FFFF || code.between?(0xD800, 0xDFFF)
        code.chr(Encoding::UTF_8)
      end

      def decode_binary_tag(str)
        content = str.sub(/\A!binary\s+/, "")
        content = $1 if content =~ /\A"(.*)"\z/ || content =~ /\A'(.*)'\z/
        content.unpack1("m")
      end

      def parse_binary_value(val, indent)
        rest = val.sub(/\A!binary\s+/, "")
        if rest.start_with?("|")
          content = parse_block_scalar(indent, rest[1..].to_s.strip)
          Scalar.new(content.unpack1("m"))
        else
          Scalar.new(decode_binary_tag(val))
        end
      end

      def parse_alias_ref
        AliasRef.new(@lines.shift.lstrip[1..].strip)
      end

      def parse_inline_alias(content)
        AliasRef.new(content[1..].strip)
      end

      def current_indent
        indent_of(@lines[0])
      end

      def indent_of(line)
        i = 0
        i += 1 while LSTRIP_BYTES.include?(line.getbyte(i))
        i
      end

      def consume_anchor
        line = @lines[0]
        stripped = line.lstrip
        return nil unless stripped.start_with?("&") && stripped =~ /^&(\S+)\s*/

        anchor = $1
        if $'.empty?
          @lines.shift
        else
          @lines[0] = line.sub(/&#{Regexp.escape(anchor)}\s+/, "")
        end
        anchor
      end

      def extract_anchor(content)
        return [nil, content] unless content =~ /^&(\S+)/

        anchor = $1
        [anchor, content.sub(/^&#{Regexp.escape(anchor)}\s*/, "")]
      end

      def register_anchor(name, node)
        if name
          # An anchored empty node still defines the anchor, as a null.
          node ||= Scalar.new(nil)
          @anchors[name] = node
          node.anchor = name if node.respond_to?(:anchor=)
        end
        node
      end

      def raise_max_nesting!
        message = "exceeded maximum nesting depth (#{MAX_NESTING_DEPTH})"
        if defined?(Psych::VERSION)
          raise Psych::SyntaxError.new(nil, 0, 0, 0, message, nil)
        else
          raise Psych::SyntaxError, message
        end
      end

      def skip_blank_and_comments
        @lines.shift while @lines.any? && BLANK_OR_COMMENT_RE.match?(@lines[0])
      end

      def strip_comment(val)
        return val unless val.include?("#")
        return "" if val.lstrip.start_with?("#")

        in_single = false
        in_double = false
        escape = false

        val.each_char.with_index do |ch, i|
          if escape
            escape = false
            next
          end

          if in_single
            in_single = false if ch == "'"
          elsif in_double
            if ch == "\\"
              escape = true
            elsif ch == '"'
              in_double = false
            end
          else
            case ch
            when "'" then in_single = true
            when '"' then in_double = true
            when "#"
              # A "#" starts a comment only when preceded by whitespace.
              return val[0...i].rstrip if [" ", "\t"].include?(val[i - 1])
            end
          end
        end

        val
      end
    end

    class Builder
      VALID_OPS = %w[= != > < >= <= ~>].freeze
      ARRAY_FIELDS = %w[files test_files executables extra_rdoc_files].freeze
      MAX_ALIAS_EXPANSION = 100_000

      def initialize(permitted_classes: [], permitted_symbols: [], aliases: true)
        @permitted_classes = permitted_classes.map {|c| "!ruby/object:#{c}" }
        @permitted_symbols = permitted_symbols
        @aliases = aliases
        @anchor_values = {}
        @anchor_sizes = {}
        @expanded_size = 0
        @alias_expansion = 0
      end

      def build(node)
        return nil if node.nil?

        result = build_node(node)

        if result.is_a?(Hash) && result[:tag] == "!ruby/object:Gem::Specification"
          build_specification(result)
        else
          result
        end
      end

      private

      def build_node(node)
        start = @expanded_size
        case node
        when nil then nil
        when AliasRef then resolve_alias(node)
        when Scalar then store_anchor(node.anchor, node.value, start)
        when Mapping then store_anchor(node.anchor, build_mapping(node), start)
        when Sequence then store_anchor(node.anchor, node.items.map {|item| build_node(item) }, start)
        else node # already a Ruby object
        end
      end

      def resolve_alias(node)
        raise Psych::AliasesNotEnabled unless @aliases
        unless @anchor_values.key?(node.name)
          raise Psych::AnchorNotDefined, node.name if defined?(Psych::AnchorNotDefined)
          raise Psych::BadAlias, "An alias referenced an unknown anchor: #{node.name}"
        end
        # Charge the expanded size of the anchor, weighing scalars by length,
        # so neither nested aliases nor aliases to a long string blow up.
        size = @anchor_sizes.fetch(node.name)
        @expanded_size += size
        @alias_expansion += size
        if @alias_expansion > MAX_ALIAS_EXPANSION
          raise Psych::BadAlias, "exceeded maximum alias expansion (#{MAX_ALIAS_EXPANSION})"
        end
        @anchor_values.fetch(node.name)
      end

      def store_anchor(name, value, start)
        @expanded_size += value.is_a?(String) ? 1 + value.bytesize : 1
        if name
          @anchor_values[name] = value
          @anchor_sizes[name] = @expanded_size - start
        end
        value
      end

      def build_mapping(node)
        validate_tag!(node.tag) if node.tag

        result = case node.tag
                 when "!ruby/object:Gem::Version"
                   build_version(node)
                 when "!ruby/object:Gem::Platform"
                   build_platform(node)
                 when "!ruby/object:Gem::Requirement", "!ruby/object:Gem::Version::Requirement"
                   build_requirement(node)
                 when "!ruby/object:Gem::Dependency"
                   build_dependency(node)
                 when nil
                   build_hash(node)
                 when "!ruby/object:Gem::Specification"
                   hash = build_hash(node)
                   hash[:tag] = node.tag
                   hash
                 else
                   raise ArgumentError, "undefined class/module #{node.tag.sub("!ruby/object:", "")}"
        end

        result
      end

      def build_hash(node)
        result = {}
        each_pair(node) do |key, value_node|
          value = build_node(value_node)

          if ARRAY_FIELDS.include?(key)
            value = normalize_array_field(value)
          end

          result[key] = value
        end
        result
      end

      def build_version(node)
        hash = pairs_to_hash(node)
        Gem::Version.new((hash["version"] || hash["value"]).to_s)
      end

      PLATFORM_FIELDS = %w[cpu os version].freeze
      PLATFORM_ALLOWED_IVARS = %w[cpu os version value].freeze

      def build_platform(node)
        hash = pairs_to_hash(node)
        if (hash.keys & PLATFORM_FIELDS).any?
          Gem::Platform.new([hash["cpu"], hash["os"], hash["version"]])
        elsif hash["value"].is_a?(Array)
          # Malformed platform (e.g. sequence instead of mapping).
          # Return the raw value so yaml_initialize handles it like Psych does.
          hash["value"]
        else
          plat = Gem::Platform.allocate
          hash.each do |k, v|
            plat.instance_variable_set(:"@#{k}", v) if PLATFORM_ALLOWED_IVARS.include?(k)
          end
          plat
        end
      end

      def build_requirement(node)
        r = Gem::Requirement.allocate
        hash = pairs_to_hash(node)
        reqs = hash["requirements"] || hash["value"]

        if reqs.is_a?(Array) && !reqs.empty?
          safe_reqs = []
          reqs.each do |item|
            if item.is_a?(Array) && item.size == 2
              op = item[0].to_s
              ver = item[1]
              if VALID_OPS.include?(op)
                version_obj = ver.is_a?(Gem::Version) ? ver : Gem::Version.new(ver.to_s)
                safe_reqs << [op, version_obj]
              end
            elsif item.is_a?(String)
              parsed = Gem::Requirement.parse(item)
              safe_reqs << parsed
            end
          rescue Gem::Requirement::BadRequirementError, Gem::Version::BadVersionError
            # Skip malformed items silently
          end
          reqs = safe_reqs unless safe_reqs.empty?
        end

        r.instance_variable_set(:@requirements, reqs)
        r
      end

      def build_dependency(node)
        hash = pairs_to_hash(node)
        d = Gem::Dependency.allocate
        d.instance_variable_set(:@name, hash["name"])

        d.instance_variable_set(:@requirement, hash["requirement"] || hash["version_requirements"])

        raw_type = hash["type"]
        if raw_type
          name = raw_type.to_s.sub(/^:/, "")
          validate_symbol!(name)
          type = name.to_sym
        else
          type = :runtime
        end
        d.instance_variable_set(:@type, type)

        d.instance_variable_set(:@prerelease, ["true", true].include?(hash["prerelease"]))
        d.instance_variable_set(:@version_requirements, d.instance_variable_get(:@requirement))
        d
      end

      def build_specification(hash)
        spec = Gem::Specification.allocate

        normalize_specification_version!(hash)
        normalize_array_fields!(hash)

        spec.yaml_initialize("!ruby/object:Gem::Specification", hash)
        spec
      end

      def pairs_to_hash(node)
        result = {}
        each_pair(node) do |key, value_node|
          result[key] = build_node(value_node)
        end
        result
      end

      def each_pair(node)
        pairs = node.pairs
        i = 0
        while i < pairs.size
          yield pairs[i], pairs[i + 1]
          i += 2
        end
      end

      def validate_tag!(tag)
        return if @permitted_classes.include?(tag)
        raise_disallowed_class!(tag)
      end

      def raise_disallowed_class!(tag)
        if defined?(Psych::VERSION)
          raise Psych::DisallowedClass.new("load", tag)
        else
          raise Psych::DisallowedClass, "Tried to load unspecified class: #{tag}"
        end
      end

      def validate_symbol!(name)
        return if @permitted_symbols.empty? || @permitted_symbols.include?(name)

        label = ":#{name}"
        if defined?(Psych::VERSION)
          raise Psych::DisallowedClass.new("load", label)
        else
          raise Psych::DisallowedClass, "Tried to load unspecified class: #{label}"
        end
      end

      def normalize_specification_version!(hash)
        val = hash["specification_version"]
        return unless val && !val.is_a?(Integer)
        hash["specification_version"] = val.to_i if val.is_a?(String) && /\A\d+\z/.match?(val)
      end

      def normalize_array_fields!(hash)
        ARRAY_FIELDS.each do |field|
          hash[field] = normalize_array_field(hash[field]) if hash[field]
        end
      end

      def normalize_array_field(value)
        if value.is_a?(Hash)
          value.values.flatten.compact
        elsif !value.is_a?(Array) && value
          [value].flatten.compact
        else
          value
        end
      end
    end

    class Emitter
      STRING_ESCAPES = {
        "\\" => "\\\\",
        "\"" => "\\\"",
        "\0" => "\\0",
        "\a" => "\\a",
        "\b" => "\\b",
        "\t" => "\\t",
        "\n" => "\\n",
        "\v" => "\\v",
        "\f" => "\\f",
        "\r" => "\\r",
        "\e" => "\\e",
      }.freeze

      def emit(obj)
        res = "---#{emit_node(obj, 0)}"
        res << "...\n" if @open_ended
        res
      end

      private

      def emit_node(obj, indent, quote: false)
        case obj
        when Gem::Specification then emit_specification(obj, indent)
        when Gem::Version       then emit_version(obj, indent)
        when Gem::Platform      then emit_platform(obj, indent)
        when Gem::Requirement   then emit_requirement(obj, indent)
        when Gem::Dependency    then emit_dependency(obj, indent)
        when Hash               then emit_hash(obj, indent)
        when Array              then emit_array(obj, indent)
        when Time               then emit_time(obj)
        when String             then emit_string(obj, indent, quote: quote)
        when NilClass
          "\n"
        when Numeric, Symbol, TrueClass, FalseClass
          " #{obj.inspect}\n"
        else
          " #{quote_string(obj.to_s)}\n"
        end
      end

      def emit_specification(spec, indent)
        parts = [" !ruby/object:Gem::Specification\n"]
        parts << "#{pad(indent)}name:#{emit_node(spec.name, indent + 2)}"
        parts << "#{pad(indent)}version:#{emit_node(spec.version, indent + 2)}"
        parts << "#{pad(indent)}platform: #{spec.platform}\n"
        if spec.platform.to_s != spec.original_platform.to_s
          parts << "#{pad(indent)}original_platform: #{spec.original_platform}\n"
        end

        attributes = Gem::Specification.attribute_names.map(&:to_s).sort - %w[name version platform]
        attributes.each do |name|
          val = spec.instance_variable_get("@#{name}")
          next if val.nil?
          parts << "#{pad(indent)}#{name}:#{emit_node(val, indent + 2)}"
        end

        res = parts.join
        res << "\n" unless res.end_with?("\n")
        res
      end

      def emit_version(ver, indent)
        " !ruby/object:Gem::Version\n" \
          "#{pad(indent)}version: #{emit_node(ver.version.to_s, indent + 2).lstrip}"
      end

      def emit_platform(plat, indent)
        " !ruby/object:Gem::Platform\n" \
          "#{pad(indent)}cpu:#{emit_node(plat.cpu, indent + 2)}" \
          "#{pad(indent)}os:#{emit_node(plat.os, indent + 2)}" \
          "#{pad(indent)}version:#{emit_node(plat.version, indent + 2)}"
      end

      def emit_requirement(req, indent)
        " !ruby/object:Gem::Requirement\n" \
          "#{pad(indent)}requirements:#{emit_node(req.requirements, indent + 2)}"
      end

      def emit_dependency(dep, indent)
        [
          " !ruby/object:Gem::Dependency\n",
          "#{pad(indent)}name: #{emit_node(dep.name, indent + 2).lstrip}",
          "#{pad(indent)}requirement:#{emit_node(dep.requirement, indent + 2)}",
          "#{pad(indent)}type: #{emit_node(dep.type, indent + 2).lstrip}",
          "#{pad(indent)}prerelease: #{emit_node(dep.prerelease?, indent + 2).lstrip}",
          "#{pad(indent)}version_requirements:#{emit_node(dep.requirement, indent + 2)}",
        ].join
      end

      def emit_hash(hash, indent)
        if hash.empty?
          " {}\n"
        else
          parts = ["\n"]
          hash.each do |k, v|
            is_symbol = k.is_a?(Symbol) || (k.is_a?(String) && k.start_with?(":"))
            key_str = k.is_a?(Symbol) ? k.inspect : k.to_s
            key_str = quote_string(key_str) if !is_symbol && needs_quoting?(key_str)
            parts << "#{pad(indent)}#{key_str}:#{emit_node(v, indent + 2, quote: is_symbol)}"
          end
          parts.join
        end
      end

      def emit_array(arr, indent)
        if arr.empty?
          " []\n"
        else
          parts = ["\n"]
          arr.each do |v|
            parts << "#{pad(indent)}-#{emit_node(v, indent + 2)}"
          end
          parts.join
        end
      end

      def emit_time(time)
        " #{time.utc.strftime("%Y-%m-%d %H:%M:%S.%N Z")}\n"
      end

      def emit_string(str, indent, quote: false)
        # A CR cannot be represented in a block scalar because parsing
        # normalizes CRLF line breaks to LF, so quote and escape instead.
        if str.include?("\n") && !str.include?("\r")
          emit_block_scalar(str, indent)
        elsif needs_quoting?(str, quote)
          " #{quote_string(str)}\n"
        else
          " #{str}\n"
        end
      end

      def emit_block_scalar(str, indent)
        # The root node has no parent to be indented from, so indent its
        # content by one level like libyaml does.
        indent = 2 if indent.zero?
        parts = [" |#{block_scalar_header(str)}\n"]
        str.each_line do |line|
          parts << (line == "\n" ? line : "#{pad(indent)}#{line}")
        end
        res = parts.join
        res << "\n" unless res.end_with?("\n")
        res
      end

      # Mirrors libyaml: an explicit indentation indicator when the first
      # line is empty or starts with a space (a parser would otherwise take
      # that whitespace as the block indentation and drop it), "-" when the
      # content does not end with a line break and "+" when it ends with
      # more than one, which also requires a document end marker.
      def block_scalar_header(str)
        header = +""
        header << "2" if str.start_with?(" ", "\n")
        if !str.end_with?("\n")
          header << "-"
        elsif str.end_with?("\n\n") || str == "\n"
          header << "+"
          @open_ended = true
        end
        header
      end

      def needs_quoting?(str, quote = false)
        quote || str.empty? || str != str.strip || str =~ /[[:cntrl:]]/ ||
          str =~ /^[!*&:@%$"'|`]/ || str =~ /^-?\d+(\.\d+)?$/ || str =~ /^[<>=-]/ ||
          str == "true" || str == "false" || str == "nil" || str == "null" || str == "~" ||
          str.include?(":") || str.include?("#") || str.include?("[") || str.include?("]") ||
          str.include?("{") || str.include?("}") || str.include?(",")
      end

      def quote_string(str)
        %("#{str.gsub(/[\\"]|[[:cntrl:]]/) {|c| STRING_ESCAPES[c] || format("\\x%02X", c.ord) }}")
      end

      def pad(indent)
        " " * indent
      end
    end

    module_function

    def dump(obj)
      Emitter.new.emit(obj)
    end

    def load(str, permitted_classes: [], permitted_symbols: [], aliases: true)
      ast = Parser.new(str).parse
      result = Builder.new(
        permitted_classes: permitted_classes,
        permitted_symbols: permitted_symbols,
        aliases: aliases
      ).build(ast)
      # Bundler 4.0 and older call Hash methods on what this returns for
      # .bundle/config, which is just "---" once its last key is unset, so
      # nil stays a Hash here as it did in RubyGems 4.0.
      result.nil? ? {} : result
    end
  end
end
